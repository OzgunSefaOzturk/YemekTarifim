<?php
	session_start();

	unset($_SESSION['user']);

	echo "Çıkış yapıldı";
?>