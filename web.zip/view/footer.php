<div class="clear"></div></div>
			<div class="container-fluid cızgıa"></div>


			<div class="container-fluid footer">
				<div class="col-md-6 sol">Hakları bana ait çalanı sikerim.
				</div>
				<div class="col-md-6 sag">
					<a href="/web/?page=hakkimizda">Hakkımızda</a>
					<a href="/web/?page=iletisim">İletişim</a>
				</div>
			</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    	<script src="/web/style/js/bootstrap.min.js"></script>